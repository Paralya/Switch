execute if score #temp switch.data matches 192 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 196 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 204 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.793701 1