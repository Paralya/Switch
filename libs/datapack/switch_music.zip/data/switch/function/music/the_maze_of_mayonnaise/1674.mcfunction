playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.629961 1