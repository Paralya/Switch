playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.629961 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.529732 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.840896 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.887749 1