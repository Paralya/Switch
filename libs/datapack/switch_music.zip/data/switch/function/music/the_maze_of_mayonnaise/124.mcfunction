execute if score #temp switch.data matches 1984 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 1988 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 1988 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1
execute if score #temp switch.data matches 1992 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 1992 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 1996 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 1996 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1