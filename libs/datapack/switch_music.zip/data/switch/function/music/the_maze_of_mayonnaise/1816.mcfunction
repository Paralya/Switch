playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.681793 1
playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.840896 1