execute if score #temp switch.data matches 1920 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 1924 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 1924 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1
execute if score #temp switch.data matches 1928 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.189207 1
execute if score #temp switch.data matches 1928 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 1932 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 1932 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1