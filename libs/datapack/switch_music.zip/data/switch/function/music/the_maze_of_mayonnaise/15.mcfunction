execute if score #temp switch.data matches 240 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 244 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 252 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.587401 1