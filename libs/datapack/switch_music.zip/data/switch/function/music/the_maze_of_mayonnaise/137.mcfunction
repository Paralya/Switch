execute if score #temp switch.data matches 2194 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 2194 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 2200 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 2200 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1