execute if score #temp switch.data matches 2064 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.681793 1
execute if score #temp switch.data matches 2064 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 2068 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.887749 1
execute if score #temp switch.data matches 2070 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 2072 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 2076 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 2076 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.887749 1