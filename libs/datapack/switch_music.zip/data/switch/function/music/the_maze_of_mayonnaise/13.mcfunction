execute if score #temp switch.data matches 208 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.793701 1
execute if score #temp switch.data matches 212 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.793701 1
execute if score #temp switch.data matches 214 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 218 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 220 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.189207 1
execute if score #temp switch.data matches 222 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.189207 1