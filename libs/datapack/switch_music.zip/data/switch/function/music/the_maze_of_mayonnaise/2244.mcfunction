playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.793701 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1