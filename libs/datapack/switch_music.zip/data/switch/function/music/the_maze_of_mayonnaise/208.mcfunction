execute if score #temp switch.data matches 3328 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.529732 1
execute if score #temp switch.data matches 3328 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.529732 1
execute if score #temp switch.data matches 3328 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
execute if score #temp switch.data matches 3328 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.793701 1
execute if score #temp switch.data matches 3328 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 3332 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.189207 1
execute if score #temp switch.data matches 3336 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 3340 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.189207 1