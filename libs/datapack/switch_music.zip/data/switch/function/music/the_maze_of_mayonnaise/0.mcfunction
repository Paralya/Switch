execute if score #temp switch.data matches 0 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 4 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 8 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 12 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1