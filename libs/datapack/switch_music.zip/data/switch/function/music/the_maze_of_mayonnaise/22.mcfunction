execute if score #temp switch.data matches 352 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 352 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 356 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 356 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 364 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 364 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 366 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.498307 1
execute if score #temp switch.data matches 366 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.498307 1