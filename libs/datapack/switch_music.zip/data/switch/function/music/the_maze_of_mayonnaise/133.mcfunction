execute if score #temp switch.data matches 2128 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.189207 1
execute if score #temp switch.data matches 2128 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 2132 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 2132 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.887749 1
execute if score #temp switch.data matches 2136 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 2140 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.189207 1
execute if score #temp switch.data matches 2140 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.887749 1