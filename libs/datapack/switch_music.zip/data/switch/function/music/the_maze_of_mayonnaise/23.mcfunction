execute if score #temp switch.data matches 368 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 368 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 372 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 372 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 380 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 380 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.587401 1