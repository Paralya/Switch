playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.587401 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.189207 1