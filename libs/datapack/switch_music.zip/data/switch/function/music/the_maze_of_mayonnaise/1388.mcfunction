playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.587401 1
playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.529732 1
playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1