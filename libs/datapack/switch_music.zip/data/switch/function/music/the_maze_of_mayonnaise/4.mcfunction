execute if score #temp switch.data matches 64 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 68 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 72 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 76 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1