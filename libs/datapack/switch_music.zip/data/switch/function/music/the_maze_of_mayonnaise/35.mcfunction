execute if score #temp switch.data matches 560 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 566 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 572 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.587401 1