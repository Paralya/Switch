execute if score #temp switch.data matches 224 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 228 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 236 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 238 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.498307 1