execute if score #temp switch.data matches 80 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 84 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 88 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 92 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.000000 1