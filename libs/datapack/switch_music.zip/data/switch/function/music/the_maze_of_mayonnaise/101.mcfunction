execute if score #temp switch.data matches 1624 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.793701 1
execute if score #temp switch.data matches 1624 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.000000 1
execute if score #temp switch.data matches 1624 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.189207 1
execute if score #temp switch.data matches 1624 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1