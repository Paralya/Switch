execute if score #temp switch.data matches 256 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 260 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 268 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.414214 1