playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.587401 1
playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1