execute if score #temp switch.data matches 2640 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.500000 1
execute if score #temp switch.data matches 2640 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.594604 1
execute if score #temp switch.data matches 2640 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.793701 1
execute if score #temp switch.data matches 2640 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.793701 1
execute if score #temp switch.data matches 2652 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.500000 1
execute if score #temp switch.data matches 2652 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.594604 1
execute if score #temp switch.data matches 2652 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.793701 1
execute if score #temp switch.data matches 2652 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.793701 1