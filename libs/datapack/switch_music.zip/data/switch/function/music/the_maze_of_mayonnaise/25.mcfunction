execute if score #temp switch.data matches 400 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 400 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 404 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 404 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 408 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 408 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 412 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.189207 1
execute if score #temp switch.data matches 412 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.189207 1