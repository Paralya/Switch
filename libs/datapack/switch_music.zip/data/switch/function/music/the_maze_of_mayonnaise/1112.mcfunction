playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.500000 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.594604 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.793701 1
playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.629961 1
playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.793701 1