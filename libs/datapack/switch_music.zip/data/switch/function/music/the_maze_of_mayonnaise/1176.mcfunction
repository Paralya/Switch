playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.707107 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1