execute if score #temp switch.data matches 1888 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 1888 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 1892 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.793701 1
execute if score #temp switch.data matches 1892 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.529732 1
execute if score #temp switch.data matches 1896 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 1900 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.529732 1