execute if score #temp switch.data matches 2032 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 2036 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.529732 1
execute if score #temp switch.data matches 2040 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 2044 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.529732 1