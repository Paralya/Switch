execute if score #temp switch.data matches 2000 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 2000 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 2004 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.189207 1
execute if score #temp switch.data matches 2004 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.887749 1
execute if score #temp switch.data matches 2008 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 2012 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.189207 1
execute if score #temp switch.data matches 2012 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.887749 1