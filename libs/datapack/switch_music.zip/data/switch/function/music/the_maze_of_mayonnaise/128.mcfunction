execute if score #temp switch.data matches 2048 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 2052 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.887749 1
execute if score #temp switch.data matches 2052 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1
execute if score #temp switch.data matches 2056 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 2058 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.887749 1
execute if score #temp switch.data matches 2060 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1