playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.059463 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.189207 1