playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.887749 1
playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.943874 1