execute if score #temp switch.data matches 496 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 496 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 500 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 500 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 508 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 508 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.587401 1