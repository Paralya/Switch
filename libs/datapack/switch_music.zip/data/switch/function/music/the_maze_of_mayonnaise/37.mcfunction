execute if score #temp switch.data matches 592 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.587401 1
execute if score #temp switch.data matches 596 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 596 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 600 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 600 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 604 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.189207 1
execute if score #temp switch.data matches 604 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.189207 1