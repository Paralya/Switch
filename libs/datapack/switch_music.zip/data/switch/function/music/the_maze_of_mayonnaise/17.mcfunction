execute if score #temp switch.data matches 272 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 276 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 280 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 284 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.189207 1