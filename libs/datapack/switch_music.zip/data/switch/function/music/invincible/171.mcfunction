execute if score #temp switch.data matches 2736 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 2742 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.529732 1
execute if score #temp switch.data matches 2745 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.887749 1