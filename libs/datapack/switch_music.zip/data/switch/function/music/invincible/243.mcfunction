execute if score #temp switch.data matches 3888 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 3888 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 3888 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 3888 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 3899 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 3900 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 3900 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.561231 1