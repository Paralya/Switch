execute if score #temp switch.data matches 132 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 132 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 132 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.887749 1
execute if score #temp switch.data matches 132 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.498307 1
execute if score #temp switch.data matches 132 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.749154 1
execute if score #temp switch.data matches 138 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1