execute if score #temp switch.data matches 2880 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
execute if score #temp switch.data matches 2892 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.529732 1
execute if score #temp switch.data matches 2892 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.529732 1