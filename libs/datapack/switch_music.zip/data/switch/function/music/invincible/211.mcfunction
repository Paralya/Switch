execute if score #temp switch.data matches 3378 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.498307 1
execute if score #temp switch.data matches 3384 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 3384 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.629961 1
execute if score #temp switch.data matches 3384 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 3390 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1