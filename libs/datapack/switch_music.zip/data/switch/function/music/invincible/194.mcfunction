execute if score #temp switch.data matches 3105 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.887749 1
execute if score #temp switch.data matches 3114 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 3119 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.529732 1