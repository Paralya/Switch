execute if score #temp switch.data matches 69 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 69 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
execute if score #temp switch.data matches 69 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 69 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.529732 1