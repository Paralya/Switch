execute if score #temp switch.data matches 496 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 498 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 502 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 504 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 504 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 504 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 504 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.943874 1