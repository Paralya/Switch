execute if score #temp switch.data matches 4402 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 4402 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 4402 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 4408 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 4414 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1