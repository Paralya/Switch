execute if score #temp switch.data matches 1620 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 1620 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1
execute if score #temp switch.data matches 1620 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 1622 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 1624 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 1626 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 1628 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 1630 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1