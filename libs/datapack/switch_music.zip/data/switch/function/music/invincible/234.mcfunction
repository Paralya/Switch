execute if score #temp switch.data matches 3744 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 3756 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 3756 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 3758 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1