execute if score #temp switch.data matches 2130 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1
execute if score #temp switch.data matches 2130 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.529732 1
execute if score #temp switch.data matches 2130 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
execute if score #temp switch.data matches 2136 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 2136 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 2137 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 2138 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.561231 1