execute if score #temp switch.data matches 1056 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 1068 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 1068 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 1070 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1