execute if score #temp switch.data matches 3923 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 3924 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 3924 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 3929 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 3930 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 3935 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 3935 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.561231 1