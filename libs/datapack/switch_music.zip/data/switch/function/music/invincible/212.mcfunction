execute if score #temp switch.data matches 3396 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1
execute if score #temp switch.data matches 3396 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 3396 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 3396 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 3396 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.629961 1
execute if score #temp switch.data matches 3402 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1