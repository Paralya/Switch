execute if score #temp switch.data matches 304 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 306 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 308 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 310 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 312 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 312 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 312 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 312 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1