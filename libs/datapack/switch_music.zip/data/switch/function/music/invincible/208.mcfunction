execute if score #temp switch.data matches 3330 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 3336 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.749154 1
execute if score #temp switch.data matches 3336 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 3336 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 3342 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1