execute if score #temp switch.data matches 1234 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 1236 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 1236 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 1240 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 1242 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 1246 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 1246 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.561231 1