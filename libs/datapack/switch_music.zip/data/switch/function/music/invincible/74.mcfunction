execute if score #temp switch.data matches 1186 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 1188 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 1188 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 1192 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 1194 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 1198 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 1198 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1