execute if score #temp switch.data matches 1524 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 1524 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1
execute if score #temp switch.data matches 1524 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 1526 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 1528 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 1530 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 1532 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 1534 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1