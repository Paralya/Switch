execute if score #temp switch.data matches 2616 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1
execute if score #temp switch.data matches 2616 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 2616 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1