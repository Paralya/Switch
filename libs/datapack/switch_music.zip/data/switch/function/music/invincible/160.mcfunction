execute if score #temp switch.data matches 2562 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.887749 1
execute if score #temp switch.data matches 2568 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.887749 1
execute if score #temp switch.data matches 2568 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.498307 1
execute if score #temp switch.data matches 2568 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.749154 1