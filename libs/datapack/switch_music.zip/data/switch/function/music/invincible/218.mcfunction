execute if score #temp switch.data matches 3492 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 3492 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 3492 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.887749 1
execute if score #temp switch.data matches 3492 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 3492 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.887749 1
execute if score #temp switch.data matches 3498 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.414214 1