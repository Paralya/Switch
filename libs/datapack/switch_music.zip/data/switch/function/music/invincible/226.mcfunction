execute if score #temp switch.data matches 3618 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 3624 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 3624 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.059463 1
execute if score #temp switch.data matches 3624 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.529732 1
execute if score #temp switch.data matches 3630 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1