execute if score #temp switch.data matches 688 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 690 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 694 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 696 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 696 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 696 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 696 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1