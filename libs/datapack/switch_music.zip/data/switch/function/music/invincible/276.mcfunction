execute if score #temp switch.data matches 4417 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 4423 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 4423 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.840896 1
execute if score #temp switch.data matches 4429 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.681793 1
execute if score #temp switch.data matches 4429 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
execute if score #temp switch.data matches 4429 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.529732 1