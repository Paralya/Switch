execute if score #temp switch.data matches 3252 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.629961 1
execute if score #temp switch.data matches 3254 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 3255 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.887749 1
execute if score #temp switch.data matches 3257 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.681793 1
execute if score #temp switch.data matches 3258 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 3260 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.259921 1
execute if score #temp switch.data matches 3261 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.414214 1
execute if score #temp switch.data matches 3263 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.681793 1