execute if score #temp switch.data matches 3875 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 3876 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 3876 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 3881 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.122462 1
execute if score #temp switch.data matches 3882 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
execute if score #temp switch.data matches 3887 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.561231 1
execute if score #temp switch.data matches 3887 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.122462 1