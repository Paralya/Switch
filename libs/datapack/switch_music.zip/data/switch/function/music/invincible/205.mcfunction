execute if score #temp switch.data matches 3282 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.629961 1
execute if score #temp switch.data matches 3285 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 3288 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 3288 run playsound minecraft:block.note_block.harp_1 record @s ^0 ^ ^ 1 0.943874 1
execute if score #temp switch.data matches 3288 run playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.887749 1
execute if score #temp switch.data matches 3294 run playsound minecraft:block.note_block.harp_-1 record @s ^0 ^ ^ 1 1.414214 1