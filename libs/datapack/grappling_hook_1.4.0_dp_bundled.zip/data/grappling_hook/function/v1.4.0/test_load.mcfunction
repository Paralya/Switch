function grappling_hook:v1.4.0/load
