advancement revoke @s only grappling_hook:v1.4.0/replace_guide
execute if items entity @s weapon.mainhand written_book[custom_data~{smithed: {id: "grappling_hook:guide"}}, !custom_data~{grappling_hook: {version: {major: 1, minor: 4, patch: 0}}}] run function grappling_hook:v1.4.0/replace_guide/modify
