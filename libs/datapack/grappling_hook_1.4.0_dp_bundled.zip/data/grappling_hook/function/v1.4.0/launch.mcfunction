scoreboard players operation $x player_motion.api.launch = @s grappling_hook.launch.x
scoreboard players operation $y player_motion.api.launch = @s grappling_hook.launch.y
scoreboard players operation $z player_motion.api.launch = @s grappling_hook.launch.z
function player_motion:api/launch_xyz
