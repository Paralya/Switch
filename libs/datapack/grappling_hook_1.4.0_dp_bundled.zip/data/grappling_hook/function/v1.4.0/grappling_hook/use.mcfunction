advancement revoke @s only grappling_hook:v1.4.0/grappling_hook
tag @s add grappling_hook.player.me
execute as @e[type=arrow, tag=grappling_hook.arrow] run function grappling_hook:v1.4.0/grappling_hook/check_origin
tag @s remove grappling_hook.player.me
