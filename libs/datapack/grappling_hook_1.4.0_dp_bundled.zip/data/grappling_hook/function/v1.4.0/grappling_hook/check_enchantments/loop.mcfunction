scoreboard players set #glint grappling_hook.data -1
scoreboard players set #slot grappling_hook.data -1
execute store result score #slot grappling_hook.data run data get storage grappling_hook:main temp.RealInventory[0].Slot
execute store result score #glint grappling_hook.data run data get storage grappling_hook:main temp.RealInventory[0].components."minecraft:enchantment_glint_override"
data remove storage grappling_hook:main temp.RealInventory[0].components."minecraft:enchantments"."grappling_hook:grappling_hook"
execute summon item_display run function grappling_hook:v1.4.0/grappling_hook/check_enchantments/loop/item_display
execute if score #has_no_enchantments grappling_hook.data matches 1 unless score #glint grappling_hook.data matches 0 run function grappling_hook:v1.4.0/grappling_hook/check_enchantments/loop/remove_glint
execute if score #has_no_enchantments grappling_hook.data matches 0 unless score #glint grappling_hook.data matches 1 run function grappling_hook:v1.4.0/grappling_hook/check_enchantments/loop/add_glint
data remove storage grappling_hook:main temp.RealInventory[0]
execute if data storage grappling_hook:main temp.RealInventory[0] run function grappling_hook:v1.4.0/grappling_hook/check_enchantments/loop
