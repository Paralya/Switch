data modify entity @s item set from storage grappling_hook:main temp.RealInventory[0]
scoreboard players set #has_no_enchantments grappling_hook.data 1
execute store result score #has_no_enchantments grappling_hook.data if items entity @s contents *[minecraft:enchantments={}]
kill @s
