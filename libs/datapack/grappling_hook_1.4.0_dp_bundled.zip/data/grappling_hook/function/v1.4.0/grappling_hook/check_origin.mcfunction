scoreboard players set #is_good_arrow grappling_hook.data 0
execute on origin if entity @s[tag=grappling_hook.player.me] run scoreboard players set #is_good_arrow grappling_hook.data 1
execute if score #is_good_arrow grappling_hook.data matches 1 run function grappling_hook:v1.4.0/grappling_hook/check_power
