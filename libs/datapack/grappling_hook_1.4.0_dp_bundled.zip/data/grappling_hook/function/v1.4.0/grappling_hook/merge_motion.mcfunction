data modify storage grappling_hook:main temp.Motion set value [0.0d, 0.0d, 0.0d]
execute store result storage grappling_hook:main temp.Motion[0] double 0.0001 run scoreboard players get #dx grappling_hook.data
execute store result storage grappling_hook:main temp.Motion[1] double 0.0001 run scoreboard players get #dy grappling_hook.data
execute store result storage grappling_hook:main temp.Motion[2] double 0.0001 run scoreboard players get #dz grappling_hook.data
data modify entity @s Motion set from storage grappling_hook:main temp.Motion
