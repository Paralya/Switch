execute if score @s grappling_hook.arrow.power matches 30.. run function grappling_hook:v1.4.0/grappling_hook/hit_block
execute unless score @s grappling_hook.arrow.power matches 30.. run kill @s
