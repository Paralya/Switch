tag @s remove grappling_hook.victim
function grappling_hook:v1.4.0/grappling_hook/player_motion
