schedule clear grappling_hook:v1.4.0/tick
execute if score #grappling_hook.major load.status matches 1 if score #grappling_hook.minor load.status matches 4 if score #grappling_hook.patch load.status matches 0 run function grappling_hook:v1.4.0/test_load
