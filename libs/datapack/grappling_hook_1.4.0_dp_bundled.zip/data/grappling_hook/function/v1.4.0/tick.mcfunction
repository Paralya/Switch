schedule function grappling_hook:v1.4.0/tick 1 replace
execute as @a[scores={grappling_hook.launch.delay=1..}] run function grappling_hook:v1.4.0/delayed_launch
execute as @e[tag=grappling_hook.arrow, tag=grappling_hook.arrow.summoned] at @s run function grappling_hook:v1.4.0/tick/arrow
scoreboard players add @e[tag=grappling_hook.arrow] grappling_hook.data 1
kill @e[tag=grappling_hook.arrow,scores={grappling_hook.data=200..}]
