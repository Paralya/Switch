tellraw @s {"text": "[Loaded Grappling Hook v1.4.0]", "color": "green"}
