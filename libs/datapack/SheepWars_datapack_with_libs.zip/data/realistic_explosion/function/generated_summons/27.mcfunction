
#> realistic_explosion:generated_summons/27
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:acacia_fence_gate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:acacia_fence_gate"}}
execute if data storage realistic_explosion:main {id:"minecraft:bamboo_fence_gate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bamboo_fence_gate"}}
execute if data storage realistic_explosion:main {id:"minecraft:black_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:black_shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:blackstone_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blackstone_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:brain_coral_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:brain_coral_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:brown_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:brown_shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:cartography_table"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cartography_table"}}
execute if data storage realistic_explosion:main {id:"minecraft:cherry_fence_gate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cherry_fence_gate"}}
execute if data storage realistic_explosion:main {id:"minecraft:closed_eyeblossom"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:closed_eyeblossom"}}
execute if data storage realistic_explosion:main {id:"minecraft:cobbled_deepslate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cobbled_deepslate"}}
execute if data storage realistic_explosion:main {id:"minecraft:cut_copper_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cut_copper_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:cut_red_sandstone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cut_red_sandstone"}}
execute if data storage realistic_explosion:main {id:"minecraft:dark_oak_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dark_oak_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:daylight_detector"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:daylight_detector"}}
execute if data storage realistic_explosion:main {id:"minecraft:dead_bubble_coral"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dead_bubble_coral"}}
execute if data storage realistic_explosion:main {id:"minecraft:gilded_blackstone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:gilded_blackstone"}}
execute if data storage realistic_explosion:main {id:"minecraft:green_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:green_shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:jungle_fence_gate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:jungle_fence_gate"}}
execute if data storage realistic_explosion:main {id:"minecraft:light_blue_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:light_blue_banner"}}
execute if data storage realistic_explosion:main {id:"minecraft:light_blue_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:light_blue_candle"}}
execute if data storage realistic_explosion:main {id:"minecraft:light_blue_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:light_blue_carpet"}}
execute if data storage realistic_explosion:main {id:"minecraft:light_gray_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:light_gray_banner"}}
execute if data storage realistic_explosion:main {id:"minecraft:light_gray_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:light_gray_candle"}}
execute if data storage realistic_explosion:main {id:"minecraft:light_gray_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:light_gray_carpet"}}
execute if data storage realistic_explosion:main {id:"minecraft:mangrove_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mangrove_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:mossy_cobblestone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mossy_cobblestone"}}
execute if data storage realistic_explosion:main {id:"minecraft:nether_brick_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:nether_brick_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:nether_brick_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:nether_brick_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:nether_quartz_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:nether_quartz_ore"}}
execute if data storage realistic_explosion:main {id:"minecraft:nether_wart_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:nether_wart_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:orange_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:orange_terracotta"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_hanging_moss"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_hanging_moss"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_oak_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_oak_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:pointed_dripstone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pointed_dripstone"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_andesite"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_andesite"}}
execute if data storage realistic_explosion:main {id:"minecraft:prismarine_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:prismarine_bricks"}}
execute if data storage realistic_explosion:main {id:"minecraft:prismarine_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:prismarine_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:purple_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:purple_terracotta"}}
execute if data storage realistic_explosion:main {id:"minecraft:red_nether_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:red_nether_bricks"}}
execute if data storage realistic_explosion:main {id:"minecraft:red_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:red_stained_glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:smooth_stone_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:smooth_stone_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:spruce_fence_gate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:spruce_fence_gate"}}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_oak_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stripped_oak_wood"}}
execute if data storage realistic_explosion:main {id:"minecraft:suspicious_gravel"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:suspicious_gravel"}}
execute if data storage realistic_explosion:main {id:"minecraft:tuff_brick_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:tuff_brick_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:verdant_froglight"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:verdant_froglight"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_fence_gate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_fence_gate"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_wart_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_wart_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_copper_bars"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_copper_bars"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_copper_bulb"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_copper_bulb"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_copper_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_copper_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:white_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:white_shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:yellow_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:yellow_terracotta"}}

