
#> realistic_explosion:generated_summons/41
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:waxed_exposed_cut_copper_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_exposed_cut_copper_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_weathered_chiseled_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_weathered_chiseled_copper"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_weathered_copper_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_weathered_copper_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_weathered_cut_copper_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_weathered_cut_copper_slab"}}

