
#> realistic_explosion:generated_summons/23
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:acacia_button"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:acacia_button"}}
execute if data storage realistic_explosion:main {id:"minecraft:acacia_leaves"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:acacia_leaves"}}
execute if data storage realistic_explosion:main {id:"minecraft:acacia_planks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:acacia_planks"}}
execute if data storage realistic_explosion:main {id:"minecraft:acacia_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:acacia_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:andesite_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:andesite_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:andesite_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:andesite_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:azalea_leaves"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:azalea_leaves"}}
execute if data storage realistic_explosion:main {id:"minecraft:bamboo_button"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bamboo_button"}}
execute if data storage realistic_explosion:main {id:"minecraft:bamboo_mosaic"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bamboo_mosaic"}}
execute if data storage realistic_explosion:main {id:"minecraft:bamboo_planks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bamboo_planks"}}
execute if data storage realistic_explosion:main {id:"minecraft:bamboo_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bamboo_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:birch_sapling"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:birch_sapling"}}
execute if data storage realistic_explosion:main {id:"minecraft:blast_furnace"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blast_furnace"}}
execute if data storage realistic_explosion:main {id:"minecraft:blue_concrete"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blue_concrete"}}
execute if data storage realistic_explosion:main {id:"minecraft:brewing_stand"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:brewing_stand"}}
execute if data storage realistic_explosion:main {id:"minecraft:cactus_flower"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cactus_flower"}}
execute if data storage realistic_explosion:main {id:"minecraft:cherry_button"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cherry_button"}}
execute if data storage realistic_explosion:main {id:"minecraft:cherry_leaves"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cherry_leaves"}}
execute if data storage realistic_explosion:main {id:"minecraft:cherry_planks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cherry_planks"}}
execute if data storage realistic_explosion:main {id:"minecraft:cherry_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cherry_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:chipped_anvil"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:chipped_anvil"}}
execute if data storage realistic_explosion:main {id:"minecraft:chiseled_tuff"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:chiseled_tuff"}}
execute if data storage realistic_explosion:main {id:"minecraft:chorus_flower"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:chorus_flower"}}
execute if data storage realistic_explosion:main {id:"minecraft:command_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:command_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:crimson_fence"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:crimson_fence"}}
execute if data storage realistic_explosion:main {id:"minecraft:crimson_roots"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:crimson_roots"}}
execute if data storage realistic_explosion:main {id:"minecraft:crimson_shelf"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:crimson_shelf"}}
execute if data storage realistic_explosion:main {id:"minecraft:cut_sandstone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cut_sandstone"}}
execute if data storage realistic_explosion:main {id:"minecraft:cyan_concrete"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cyan_concrete"}}
execute if data storage realistic_explosion:main {id:"minecraft:damaged_anvil"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:damaged_anvil"}}
execute if data storage realistic_explosion:main {id:"minecraft:dark_oak_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dark_oak_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:dark_oak_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dark_oak_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:dark_oak_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dark_oak_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:dark_oak_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dark_oak_wood"}}
execute if data storage realistic_explosion:main {id:"minecraft:decorated_pot"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:decorated_pot"}}
execute if data storage realistic_explosion:main {id:"minecraft:detector_rail"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:detector_rail"}}
execute if data storage realistic_explosion:main {id:"minecraft:diamond_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:diamond_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:emerald_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:emerald_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:gray_concrete"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:gray_concrete"}}
execute if data storage realistic_explosion:main {id:"minecraft:hanging_roots"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:hanging_roots"}}
execute if data storage realistic_explosion:main {id:"minecraft:iron_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:iron_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:jungle_button"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:jungle_button"}}
execute if data storage realistic_explosion:main {id:"minecraft:jungle_leaves"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:jungle_leaves"}}
execute if data storage realistic_explosion:main {id:"minecraft:jungle_planks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:jungle_planks"}}
execute if data storage realistic_explosion:main {id:"minecraft:jungle_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:jungle_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:lightning_rod"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lightning_rod"}}
execute if data storage realistic_explosion:main {id:"minecraft:lime_concrete"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lime_concrete"}}
execute if data storage realistic_explosion:main {id:"minecraft:mangrove_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mangrove_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:mangrove_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mangrove_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:mangrove_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mangrove_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:mangrove_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mangrove_wood"}}
execute if data storage realistic_explosion:main {id:"minecraft:mushroom_stem"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mushroom_stem"}}
execute if data storage realistic_explosion:main {id:"minecraft:nether_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:nether_bricks"}}
execute if data storage realistic_explosion:main {id:"minecraft:orange_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:orange_banner"}}
execute if data storage realistic_explosion:main {id:"minecraft:orange_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:orange_candle"}}
execute if data storage realistic_explosion:main {id:"minecraft:orange_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:orange_carpet"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_oak_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_oak_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_oak_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_oak_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_oak_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_oak_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_oak_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_oak_wood"}}
execute if data storage realistic_explosion:main {id:"minecraft:pink_concrete"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pink_concrete"}}
execute if data storage realistic_explosion:main {id:"minecraft:pitcher_plant"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pitcher_plant"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_tuff"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_tuff"}}
execute if data storage realistic_explosion:main {id:"minecraft:purple_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:purple_banner"}}
execute if data storage realistic_explosion:main {id:"minecraft:purple_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:purple_candle"}}
execute if data storage realistic_explosion:main {id:"minecraft:purple_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:purple_carpet"}}
execute if data storage realistic_explosion:main {id:"minecraft:purpur_pillar"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:purpur_pillar"}}
execute if data storage realistic_explosion:main {id:"minecraft:purpur_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:purpur_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:quartz_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:quartz_bricks"}}
execute if data storage realistic_explosion:main {id:"minecraft:quartz_pillar"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:quartz_pillar"}}
execute if data storage realistic_explosion:main {id:"minecraft:quartz_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:quartz_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:red_sandstone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:red_sandstone"}}
execute if data storage realistic_explosion:main {id:"minecraft:redstone_lamp"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:redstone_lamp"}}
execute if data storage realistic_explosion:main {id:"minecraft:smooth_basalt"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:smooth_basalt"}}
execute if data storage realistic_explosion:main {id:"minecraft:smooth_quartz"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:smooth_quartz"}}
execute if data storage realistic_explosion:main {id:"minecraft:soul_campfire"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:soul_campfire"}}
execute if data storage realistic_explosion:main {id:"minecraft:spore_blossom"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:spore_blossom"}}
execute if data storage realistic_explosion:main {id:"minecraft:spruce_button"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:spruce_button"}}
execute if data storage realistic_explosion:main {id:"minecraft:spruce_leaves"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:spruce_leaves"}}
execute if data storage realistic_explosion:main {id:"minecraft:spruce_planks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:spruce_planks"}}
execute if data storage realistic_explosion:main {id:"minecraft:spruce_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:spruce_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:sticky_piston"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:sticky_piston"}}
execute if data storage realistic_explosion:main {id:"minecraft:trapped_chest"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:trapped_chest"}}
execute if data storage realistic_explosion:main {id:"minecraft:trial_spawner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:trial_spawner"}}
execute if data storage realistic_explosion:main {id:"minecraft:tripwire_hook"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:tripwire_hook"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_button"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_button"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_fungus"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_fungus"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_hyphae"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_hyphae"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_nylium"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_nylium"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_planks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_planks"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:weeping_vines"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:weeping_vines"}}
execute if data storage realistic_explosion:main {id:"minecraft:yellow_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:yellow_banner"}}
execute if data storage realistic_explosion:main {id:"minecraft:yellow_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:yellow_candle"}}
execute if data storage realistic_explosion:main {id:"minecraft:yellow_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:yellow_carpet"}}

