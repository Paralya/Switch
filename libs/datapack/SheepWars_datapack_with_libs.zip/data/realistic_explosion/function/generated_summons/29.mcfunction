
#> realistic_explosion:generated_summons/29
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:acacia_hanging_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:acacia_hanging_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:bamboo_hanging_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bamboo_hanging_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:black_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:black_stained_glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:brown_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:brown_stained_glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:chain_command_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:chain_command_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:cherry_hanging_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cherry_hanging_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:copper_golem_statue"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:copper_golem_statue"}}
execute if data storage realistic_explosion:main {id:"minecraft:dark_oak_fence_gate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dark_oak_fence_gate"}}
execute if data storage realistic_explosion:main {id:"minecraft:dead_fire_coral_fan"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dead_fire_coral_fan"}}
execute if data storage realistic_explosion:main {id:"minecraft:dead_horn_coral_fan"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dead_horn_coral_fan"}}
execute if data storage realistic_explosion:main {id:"minecraft:dead_tube_coral_fan"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dead_tube_coral_fan"}}
execute if data storage realistic_explosion:main {id:"minecraft:deepslate_lapis_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:deepslate_lapis_ore"}}
execute if data storage realistic_explosion:main {id:"minecraft:deepslate_tile_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:deepslate_tile_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:deepslate_tile_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:deepslate_tile_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:exposed_copper_bars"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:exposed_copper_bars"}}
execute if data storage realistic_explosion:main {id:"minecraft:exposed_copper_bulb"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:exposed_copper_bulb"}}
execute if data storage realistic_explosion:main {id:"minecraft:exposed_copper_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:exposed_copper_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:green_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:green_stained_glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:jungle_hanging_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:jungle_hanging_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:light_blue_concrete"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:light_blue_concrete"}}
execute if data storage realistic_explosion:main {id:"minecraft:light_gray_concrete"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:light_gray_concrete"}}
execute if data storage realistic_explosion:main {id:"minecraft:magenta_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:magenta_shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:mangrove_fence_gate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mangrove_fence_gate"}}
execute if data storage realistic_explosion:main {id:"minecraft:medium_amethyst_bud"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:medium_amethyst_bud"}}
execute if data storage realistic_explosion:main {id:"minecraft:nether_brick_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:nether_brick_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:oxidized_cut_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:oxidized_cut_copper"}}
execute if data storage realistic_explosion:main {id:"minecraft:pale_oak_fence_gate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pale_oak_fence_gate"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_blackstone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_blackstone"}}
execute if data storage realistic_explosion:main {id:"minecraft:red_concrete_powder"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:red_concrete_powder"}}
execute if data storage realistic_explosion:main {id:"minecraft:spruce_hanging_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:spruce_hanging_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_acacia_log"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stripped_acacia_log"}}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_birch_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stripped_birch_wood"}}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_cherry_log"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stripped_cherry_log"}}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_jungle_log"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stripped_jungle_log"}}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_spruce_log"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stripped_spruce_log"}}
execute if data storage realistic_explosion:main {id:"minecraft:test_instance_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:test_instance_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_hanging_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_hanging_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_lightning_rod"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_lightning_rod"}}
execute if data storage realistic_explosion:main {id:"minecraft:white_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:white_stained_glass"}}

