
#> cinemalya:v1.0.0/intro/playsound
#
# @within	cinemalya:v1.0.0/intro/fade_in 10t replace [ scheduled ]
#

execute if entity @e[tag=cinemalya.intro.title,limit=1] run function cinemalya:v1.0.0/intro/play with storage cinemalya:work intro

