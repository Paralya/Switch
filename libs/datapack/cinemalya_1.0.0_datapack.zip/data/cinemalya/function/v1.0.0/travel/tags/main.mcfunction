
#> cinemalya:v1.0.0/travel/tags/main
#
# @executed	as the cinematic entity
#
# @within	cinemalya:v1.0.0/travel/spawn
#
# @description		Apply every tag the caller asked for on top of the conventional ones.
#

execute store result score #tag_count cinemalya.data run data get storage cinemalya:work args.tags
scoreboard players set #t cinemalya.data 0
function cinemalya:v1.0.0/travel/tags/loop

