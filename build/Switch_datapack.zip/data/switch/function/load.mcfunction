
#> switch:load
#
# @within	switch:v2.0.0/load/confirm_load
#

scoreboard objectives add switch.lang dummy

scoreboard objectives add switch.id dummy
scoreboard objectives add switch.data dummy
scoreboard objectives add switch.tutorial dummy
scoreboard objectives add switch.health health
scoreboard objectives add switch.money dummy
scoreboard objectives add switch.money_bonus dummy
scoreboard objectives add switch.last_total_games dummy
scoreboard objectives add switch.right_click minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add switch.second_right_click minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add switch.reconnect dummy
scoreboard objectives add switch.alive dummy
scoreboard objectives add switch.play_time dummy
scoreboard objectives add switch.advancements dummy
scoreboard objectives add switch.lobby_respawn dummy

scoreboard objectives add switch.death deathCount
scoreboard objectives add switch.kill playerKillCount
scoreboard objectives add switch.last_death dummy

scoreboard objectives add switch.trigger.lang trigger
scoreboard objectives add switch.trigger.help trigger
scoreboard objectives add switch.trigger.money trigger
scoreboard objectives add switch.trigger.game_vote trigger
scoreboard objectives add switch.trigger.stats trigger
scoreboard objectives add switch.trigger.changelog trigger
scoreboard objectives add switch.trigger.detach trigger
scoreboard objectives add switch.trigger.attach trigger
scoreboard objectives add switch.trigger.shop trigger
scoreboard objectives add switch.trigger.tutorial trigger
scoreboard objectives add switch.trigger.succes trigger
scoreboard objectives add switch.trigger.rating trigger
scoreboard objectives add switch.trigger.night_vision trigger
scoreboard objectives add switch.trigger.music trigger
scoreboard objectives add switch.trigger.coupdetat trigger
scoreboard objectives add switch.trigger.layout trigger

scoreboard objectives add switch.stats.kills playerKillCount
scoreboard objectives add switch.stats.deaths deathCount
scoreboard objectives add switch.stats.played dummy
scoreboard objectives add switch.stats.wins dummy
scoreboard objectives add switch.stats.winrate dummy

scoreboard objectives add switch.win_streak dummy
scoreboard objectives add switch.lobby_easter_egg_counter dummy

# Wall-clock game timer (lag resistant): the per-second signal is driven by real elapsed time
# instead of counting 20 ticks, so games/timers keep real-time pace even when the server lags.
stopwatch create switch:game_clock
stopwatch restart switch:game_clock
scoreboard players set #clock_secs switch.data 0

team add switch.no_pvp {"text":"[No PvP]"}
team add switch.detached {"text":"[Detached]","color":"dark_gray"}
team add switch.tutorial {"text":"[Tutorial]","color":"yellow"}
team modify switch.no_pvp friendlyFire false
team modify switch.no_pvp color white
team modify switch.detached friendlyFire false
team modify switch.detached color gray
team modify switch.detached prefix {"text":"[Lobby] ","color":"dark_gray"}
team modify switch.tutorial prefix {"text":"[Tutorial] ","color":"yellow"}
team modify switch.tutorial color gold

gamerule minecraft:max_command_sequence_length 2147483647
forceload add 0 0
execute in switch:game run forceload add 0 0
execute store result score #cinematic_entities switch.data if entity @e[tag=switch.cinematic]

## Storage
# tellraw @a ["\n",{"nbt":"Paralya","storage":"switch:main","interpret":true},{"text":" Souhaitez tous la bienvenue à "},{"selector":"@s","color":"aqua"},{"text":" !\nIl est le "},{"score":{"name":"#next_id","objective":"switch.data"},"color":"aqua"},{"text":"ème joueur a rejoindre !"}]
data modify storage switch:main ParalyaMusic set value {"text":"[ParalyaMusic]","color":"dark_purple"}
data modify storage switch:main ParalyaStats set value {"text":"[ParalyaStats]","color":"yellow"}
data modify storage switch:main ParalyaError set value {"text":"[ParalyaError]","color":"red"}
data modify storage switch:main ParalyaWarning set value {"text":"[Paralya]","color":"gold"}
data modify storage switch:main ParalyaHelp set value [{"text":"[","color":"dark_aqua"},{"text":"ParalyaHelp","color":"aqua"},{"text":"]","color":"dark_aqua"}]
data modify storage switch:main Paralya set value [{"text":"[","color":"dark_aqua"},{"text":"Paralya","color":"aqua"},{"text":"]","color":"dark_aqua"}]

data modify storage switch:main ParalyaSapphiresFR set value [{"text":"","color":"blue"},{"text":"[","color":"#1b1796"},{"text":"Saphirs","color":"blue"},{"text":"]","color":"#1b1796"}]
data modify storage switch:main ParalyaAstuceFR set value [{"text":"[","color":"dark_green"},{"text":"ParalyaAstuceFR","color":"green"},{"text":"]","color":"dark_green"}]
data modify storage switch:main ParalyaPvPOldFR set value {"text":"[PvP 1.8 : Vitesse d'attaque infinie]","color":"dark_aqua"}
data modify storage switch:main ParalyaPvPNewFR set value {"text":"[PvP 1.9+ : Nouveau PvP]","color":"dark_green"}

data modify storage switch:main ParalyaSapphiresEN set value [{"text":"","color":"blue"},{"text":"[","color":"#1b1796"},{"text":"Sapphires","color":"blue"},{"text":"]","color":"#1b1796"}]
data modify storage switch:main ParalyaAstuceEN set value [{"text":"[","color":"dark_green"},{"text":"ParalyaTip","color":"green"},{"text":"]","color":"dark_green"}]
data modify storage switch:main ParalyaPvPOldEN set value {"text":"[PvP 1.8 : Infinite attack speed]","color":"dark_aqua"}
data modify storage switch:main ParalyaPvPNewEN set value {"text":"[PvP 1.9+ : New PvP]","color":"dark_green"}

# Sapphire icon
# Example: tellraw @s {"nbt":"SapphireFR","storage":"switch:main","interpret":true}
data modify storage switch:main SapphireFR set value {"text":"S","color":"white","font":"switch:main","hover_event":{"action":"show_text","value":{"text":"Saphirs","color":"blue"}}}
data modify storage switch:main SapphireEN set value {"text":"S","color":"white","font":"switch:main","hover_event":{"action":"show_text","value":{"text":"Sapphires","color":"blue"}}}

# Setup stats storage if needed
execute unless data storage switch:stats all run data modify storage switch:stats all set value {player:{total_played:[],total_wins:[],total_kills:[],total_deaths:[],total_money:[],played_win_ratio:[],advancement_count:[]},modes:{}}
# ex: all = {player:{total_played:[{name:"Stoupy51",value:0}],total_wins:[],total_kills:[],total_deaths:[],total_money:[],played_win_ratio:[],advancement_count:[]},modes:{pitch_creep:{total_games:0,played:[],wins:[],played_win_ratio:[]}, ...}}

# Setup storages if needed
execute unless data storage switch:ratings all run data modify storage switch:ratings all set value []
execute unless data storage switch:main UUIDs run data modify storage switch:main UUIDs set value []

# Scoreboard constants, shop load, advancements, and music load
function switch:shop/_load
function switch:advancements/_load
function switch:music/load
execute unless score #can_attach switch.data matches 0.. run scoreboard players set #can_attach switch.data 1
execute unless score #test_mode switch.data matches 0.. run scoreboard players set #test_mode switch.data 0
execute unless score #min_required switch.data matches 1.. run scoreboard players set #min_required switch.data 5

## Define mini-games list
data modify storage switch:main minigames set value []
function switch:modes/load

# Auto index
data modify storage switch:main indexed_minigames set value []
scoreboard players set #index switch.data 1
function switch:auto_index
data modify storage switch:main minigames set from storage switch:main indexed_minigames
data remove storage switch:main temp

# Map each voting group id to the list of its minigames (used to resolve a group once voted)
data modify storage switch:main groups_games set value {}
data modify storage switch:temp copy set from storage switch:main minigames
execute if data storage switch:temp copy[0] run function switch:build_groups_games with storage switch:temp copy[0]

## States
execute if score #engine_state switch.data matches -1 run tell none désactivé
execute if score #engine_state switch.data matches 0 run tell none à l arrêt
execute if score #engine_state switch.data matches 1 run tell none engine start
execute if score #engine_state switch.data matches 2 run tell none temps de vote
execute if score #engine_state switch.data matches 3 run tell none game en cours

# Games and maps picks history
execute unless data storage switch:main history run data modify storage switch:main history set value {games:[],maps:[],time_since_last_play:{}}

# Practice mode storage (lobby jumps checkpoints)
execute unless data storage switch:practice players run data modify storage switch:practice players set value []

# Jump timers (best times leaderboards)
scoreboard objectives add switch.jump_timer dummy
scoreboard objectives add switch.jump_timer_id dummy
execute unless data storage switch:jumps green run data modify storage switch:jumps green set value []
execute unless data storage switch:jumps white run data modify storage switch:jumps white set value []
execute unless data storage switch:jumps blue run data modify storage switch:jumps blue set value []
execute unless data storage switch:jumps yellow run data modify storage switch:jumps yellow set value []
execute unless data storage switch:jumps red run data modify storage switch:jumps red set value []
execute unless data storage switch:jumps brown run data modify storage switch:jumps brown set value []
execute unless data storage switch:jumps purple run data modify storage switch:jumps purple set value []
execute unless data storage switch:jumps dripstone run data modify storage switch:jumps dripstone set value []
execute unless data storage switch:jumps pink run data modify storage switch:jumps pink set value []
execute unless data storage switch:jumps bricks run data modify storage switch:jumps bricks set value []
execute unless data storage switch:jumps obsidian run data modify storage switch:jumps obsidian set value []
execute unless data storage switch:jumps duality run data modify storage switch:jumps duality set value []
execute unless data storage switch:jumps graviglitch run data modify storage switch:jumps graviglitch set value []

# One-time migration: the first version stored best times in ticks (20/s), we now use centiseconds
# (100/s). Convert every existing entry once (ticks * 5 = centiseconds). The guard score persists.
execute unless score #jump_timer_cs_migrated switch.data matches 1 run function switch:player/jump_timer/migrate
scoreboard players set #jump_timer_cs_migrated switch.data 1

# Per-player inventory layout (one score per kit role, 0 = default slot)
scoreboard objectives add switch.layout.melee dummy
scoreboard objectives add switch.layout.axe dummy
scoreboard objectives add switch.layout.ranged dummy
scoreboard objectives add switch.layout.ammo dummy
scoreboard objectives add switch.layout.tool dummy
scoreboard objectives add switch.layout.blocks dummy
scoreboard objectives add switch.layout.mobility dummy
scoreboard objectives add switch.layout.heal dummy
scoreboard objectives add switch.layout.food dummy
scoreboard objectives add switch.layout.explosive dummy
scoreboard objectives add switch.layout.throwable dummy
scoreboard objectives add switch.layout.special dummy
data modify storage switch:layout slots set value ["","hotbar.0","hotbar.1","hotbar.2","hotbar.3","hotbar.4","hotbar.5","hotbar.6","hotbar.7","hotbar.8","weapon.offhand"]

