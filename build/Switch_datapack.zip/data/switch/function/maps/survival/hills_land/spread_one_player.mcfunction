
#> switch:maps/survival/hills_land/spread_one_player
#
# @within	switch:maps/spread_one_player
#

execute in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

## Assurance commands

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

execute at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 20448 20096 0 114 under 140 false @s

