
#> switch:maps/survival/city_race/spread_players
#
# @within	???
#

execute in switch:game run spreadplayers 19939 19600 0 123 under 194 false @a[tag=!detached]

## Assurance commands

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

execute as @a[tag=!detached] at @s if entity @s[y=85,dy=-1] in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19939 19600 0 123 under 194 false @s

