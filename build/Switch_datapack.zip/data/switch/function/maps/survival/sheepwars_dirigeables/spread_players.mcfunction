
#> switch:maps/survival/sheepwars_dirigeables/spread_players
#
# @executed	as @e[type=marker,tag=switch.selected_map] & at @s
#
# @within	switch:maps/survival/sheepwars_dirigeables/teleport_players
#

execute in switch:game run spreadplayers 100053 100051 0 52 under 178 false @a[tag=!detached]

## Assurance commands

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 100053 100051 0 52 under 178 false @s

