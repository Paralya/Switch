
#> switch:maps/survival/dk_mountain/spread_one_player
#
# @within	switch:maps/spread_one_player
#

execute in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

## Assurance commands

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

execute at @s if entity @s[y=70,dy=-1] in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 19842 20544 0 59 under 202 false @s

