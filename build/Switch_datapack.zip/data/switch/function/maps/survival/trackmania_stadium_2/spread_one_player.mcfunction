
#> switch:maps/survival/trackmania_stadium_2/spread_one_player
#
# @within	switch:maps/spread_one_player
#

execute in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

## Assurance commands

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 37255 37183 0 184 under 208 false @s

