
#> switch:maps/survival/rainbow_road/spread_one_player
#
# @executed	as @e[tag=switch.block_party_mob]
#
# @within	switch:maps/spread_one_player
#

execute in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

## Assurance commands

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

execute at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s
execute at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 24061 24068 0 61 under 156 false @s

