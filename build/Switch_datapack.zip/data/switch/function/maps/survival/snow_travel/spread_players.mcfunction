
#> switch:maps/survival/snow_travel/spread_players
#
# @within	???
#

execute in switch:game run spreadplayers 23103 23102 0 103 under 176 false @a[tag=!detached]

## Assurance commands

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

execute as @a[tag=!detached] at @s if entity @s[y=100,dy=-1] in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-2 ~ barrier in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s
execute as @a[tag=!detached] at @s if block ~ ~-1 ~ #switch:not_spreadplayers in switch:game run spreadplayers 23103 23102 0 103 under 176 false @s

