
#> switch:translations/player_trigger_coupdetat_player_vote
#
# @executed	as @a[sort=random] & at @s
#
# @within	switch:player/trigger/coupdetat/player_vote
#

# French
tellraw @s[scores={switch.lang=0}] [{"nbt":"Paralya","storage":"switch:main","interpret":true},{"text":" Vous avez décidé de soutenir ce coup d'état ! Attendez la fin du vote pour savoir si vous avez réussi à renverser le gouvernement."}]

# English
tellraw @s[scores={switch.lang=1}] [{"nbt":"Paralya","storage":"switch:main","interpret":true},{"text":" You decided to support this coup d'état ! Wait for the end of the vote to know if you managed to overthrow the government."}]

