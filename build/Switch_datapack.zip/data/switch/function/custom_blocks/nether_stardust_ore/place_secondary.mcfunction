
#> switch:custom_blocks/nether_stardust_ore/place_secondary
#
# @executed	at @s
#
# @within	switch:custom_blocks/nether_stardust_ore/place_main [ at @s ]
#

# Add convention and utils tags, and the custom block tag
tag @s add global.ignore
tag @s add global.ignore.kill
tag @s add smithed.entity
tag @s add smithed.block
tag @s add switch.custom_block
tag @s add switch.nether_stardust_ore
tag @s add switch.vanilla.minecraft_polished_deepslate

# Add a custom name
data merge entity @s {"CustomName": {"text": "Nether Stardust Ore"}}

# Modify item display entity to match the custom block
item replace entity @s contents with minecraft:furnace[item_model="switch:nether_stardust_ore"]
function switch:custom_blocks/compute_brightness

