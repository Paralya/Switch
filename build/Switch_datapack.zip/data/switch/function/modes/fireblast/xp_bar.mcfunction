
#> switch:modes/fireblast/xp_bar
#
# @executed	as @a[tag=!detached,gamemode=!spectator]
#
# @within	switch:modes/fireblast/tick [ as @a[tag=!detached,gamemode=!spectator] ]
#

# 50 seconds = 100%
# 1 seconds = 1,111%
# 0 seconds = 0%
scoreboard players set #points switch.data 50
scoreboard players operation #remove switch.data = @s switch.temp.cooldown
scoreboard players operation #points switch.data -= #remove switch.data
scoreboard players operation #points switch.data *= #1000000 switch.data
scoreboard players set #divide switch.data 50000
function switch:modes/_common/xp_bar/points_at_s

scoreboard players operation #levels switch.data = @s switch.temp.cooldown
scoreboard players operation #levels switch.data /= #20 switch.data
execute if score @s switch.temp.cooldown matches 1.. run scoreboard players add #levels switch.data 1
function switch:modes/_common/xp_bar/levels_at_s

