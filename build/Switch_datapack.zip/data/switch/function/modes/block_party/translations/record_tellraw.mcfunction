
#> switch:modes/block_party/translations/record_tellraw
#
# @executed	as @n[tag=switch.coupdetat] & in switch:game
#
# @within	switch:modes/block_party/start with storage switch:records block_party
#
# @args		round (unknown)
#			player (unknown)
#

# French
$execute unless data storage switch:records block_party.runners_up[0] run tellraw @a[scores={switch.lang=0},tag=!detached] ["",{"nbt":"Paralya","storage":"switch:main","interpret":true},{"text":" Record actuel de $(round) manches détenu par $(player)","color":"#FFE60A"}]
$execute if data storage switch:records block_party.runners_up[0] run tellraw @a[scores={switch.lang=0},tag=!detached] ["",{"nbt":"Paralya","storage":"switch:main","interpret":true},{"text":" Record actuel de $(round) manches détenu par $(player)","color":"#FFE60A"},{"text":", grâce à ","color":"#AEBBD0"},{"nbt":"block_party.runners_up","storage":"switch:records","interpret":true,"separator":{"text":", "},"color":"#AEBBD0"}]

# English
$execute unless data storage switch:records block_party.runners_up[0] run tellraw @a[scores={switch.lang=1},tag=!detached] ["",{"nbt":"Paralya","storage":"switch:main","interpret":true},{"text":" Current record of $(round) rounds held by $(player)","color":"#FFE60A"}]
$execute if data storage switch:records block_party.runners_up[0] run tellraw @a[scores={switch.lang=1},tag=!detached] ["",{"nbt":"Paralya","storage":"switch:main","interpret":true},{"text":" Current record of $(round) rounds held by $(player)","color":"#FFE60A"},{"text":", thanks to ","color":"#AEBBD0"},{"nbt":"block_party.runners_up","storage":"switch:records","interpret":true,"separator":{"text":", "},"color":"#AEBBD0"}]

