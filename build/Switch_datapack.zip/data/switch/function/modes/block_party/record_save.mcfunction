
#> switch:modes/block_party/record_save
#
# @executed	as @a[tag=!detached,gamemode=!spectator]
#
# @within	switch:modes/block_party/process_end [ as @a[tag=!detached,gamemode=!spectator] ]
#

clear @s
loot replace entity @s hotbar.0 loot switch:get_username
scoreboard players set #record switch.data 0
execute store result score #record switch.data run data get storage switch:records block_party.round
execute if score #block_party_round switch.data > #record switch.data store result storage switch:records block_party.round int 1 run scoreboard players get #block_party_round switch.data
execute if score #block_party_round switch.data > #record switch.data run data modify storage switch:records block_party.player set from entity @s Inventory[0].components."minecraft:profile".name
execute if score #block_party_round switch.data > #record switch.data run data modify storage switch:records block_party.runners_up set from storage switch:temp block_party_wave
execute if score #block_party_round switch.data > #record switch.data as @a[tag=!detached] at @s run playsound ui.toast.challenge_complete ambient @s ~ ~ ~ 0.5
execute if score #block_party_round switch.data > #record switch.data run function switch:modes/block_party/translations/record_new with storage switch:records block_party

