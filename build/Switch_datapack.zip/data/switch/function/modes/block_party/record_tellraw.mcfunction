
#> switch:modes/block_party/record_tellraw
#
# @within	switch:modes/block_party/start with storage switch:records block_party
#			switch:modes/block_party/record_save with storage switch:records block_party
#

function switch:modes/block_party/translations/record_tellraw with storage switch:records block_party
scoreboard players reset #record switch.data

