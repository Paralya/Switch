
#> switch:modes/de_a_coudre/calls/start
#
# @within	???
#

execute if data storage switch:main {current_game:"de_a_coudre"} run function switch:modes/de_a_coudre/start

