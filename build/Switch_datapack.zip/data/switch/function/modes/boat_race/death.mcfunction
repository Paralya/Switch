
#> switch:modes/boat_race/death
#
# @executed	as @a[sort=random] & at @s
#
# @within	switch:modes/boat_race/calls/joined
#			switch:modes/boat_race/tick [ as @a[scores={switch.alive=1..}] & at @s ]
#			switch:modes/boat_race/process_end [ as @a[tag=!detached,sort=random] ]
#

scoreboard players set @s switch.alive 0
gamemode spectator @s
execute unless score #process_end switch.data matches 1 at @n[type=marker,tag=switch.selected_map] run tp @s ~ ~ ~ ~ ~
effect clear @s
clear @s

