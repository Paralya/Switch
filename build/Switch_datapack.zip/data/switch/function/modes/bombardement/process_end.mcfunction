
#> switch:modes/bombardement/process_end
#
# @within	switch:modes/bombardement/tick
#

scoreboard players add #process_end switch.data 1

execute if score #process_end switch.data matches 1 if score #remaining_players switch.data matches 1 as @a[tag=!detached,gamemode=!spectator] at @s run function switch:engine/add_win
execute if score #process_end switch.data matches 1 if score #remaining_players switch.data matches 1 as @a[tag=!detached,gamemode=!spectator] run function switch:modes/bombardement/record_save
function switch:translations/common/process_end_solo_winner
execute if score #process_end switch.data matches 1 as @a[tag=!detached] run gamemode spectator @s
execute if score #process_end switch.data matches 1 as @a[tag=!detached] run function switch:modes/bombardement/death
execute if score #process_end switch.data matches 1 as @a[tag=!detached] run function switch:player/trigger/rating/print_current_game

execute if score #process_end switch.data matches 200 run function switch:engine/restart

