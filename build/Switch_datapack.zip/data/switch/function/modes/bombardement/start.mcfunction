
#> switch:modes/bombardement/start
#
# @executed	as @n[tag=switch.coupdetat] & in switch:game
#
# @within	switch:modes/bombardement/calls/start
#

function switch:utils/set_dynamic_time
effect give @a[tag=!detached] weakness infinite 255 true
effect give @a[tag=!detached] saturation infinite 255 true

## Téléportation des joueurs
scoreboard players set #do_spreadplayers switch.data 0
function switch:maps/choose_map_for {id:"bombardement", maps:["bombardement"]}
tp @a[tag=!detached] 10057 109 2064 180 -30

scoreboard players set #bombardement_seconds switch.data -3
scoreboard players set #bombardement_ticks switch.data 0
scoreboard players set #process_end switch.data 0
scoreboard players set #bombardement_last_death switch.data -1
data modify storage switch:temp bombardement_wave set value []

execute if data storage switch:records bombardement run function switch:modes/bombardement/record_tellraw with storage switch:records bombardement

