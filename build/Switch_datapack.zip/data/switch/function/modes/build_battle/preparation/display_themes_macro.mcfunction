
#> switch:modes/build_battle/preparation/display_themes_macro
#
# @executed	as @a[tag=!detached] & in switch:build_battle
#
# @within	switch:modes/build_battle/preparation/display_themes with storage switch:main input
#
# @args		Slot (byte)
#			count (int)
#			plurial (string)
#

$data modify block 0 5 0 Items[$(Slot)].components."minecraft:lore" set value [[{"text":"$(count)","color":"aqua","italic":false},{"text":" vote$(plurial)","color":"gray"}]]

