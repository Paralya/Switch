
#> switch:modes/build_battle/translations/rating_time/end_calculation
#
# @executed	in switch:build_battle
#
# @within	switch:modes/build_battle/rating_time/end_calculation
#

# French
tellraw @a[scores={switch.lang=0},tag=!detached] ["\n",{"nbt":"Paralya","storage":"switch:main","interpret":true},{"text":" Classement par points :"}]
execute as @a[scores={switch.temp.rank=1}] run tellraw @a[scores={switch.lang=0},tag=!detached] [{"text":"\n1er ","color":"#FFE700"},{"text":" - ","color":"#6B788F"},{"score":{"name":"@s","objective":"switch.temp.points"}},{"text":" "},{"selector":"@s","color":"#AEBBD0"}]
execute as @a[scores={switch.temp.rank=2}] run tellraw @a[scores={switch.lang=0},tag=!detached] [{"text":"\n2ème","color":"#C0C0C0"},{"text":" - ","color":"#6B788F"},{"score":{"name":"@s","objective":"switch.temp.points"}},{"text":" "},{"selector":"@s","color":"#AEBBD0"}]
execute as @a[scores={switch.temp.rank=3}] run tellraw @a[scores={switch.lang=0},tag=!detached] [{"text":"\n3ème","color":"#CD7F32"},{"text":" - ","color":"#6B788F"},{"score":{"name":"@s","objective":"switch.temp.points"}},{"text":" "},{"selector":"@s","color":"#AEBBD0"}]
execute as @a[scores={switch.temp.rank=4..}] run tellraw @s[scores={switch.lang=0}] [{"text":"\n","color":"#AEBBD0"},{"score":{"name":"@s","objective":"switch.temp.rank"}},{"text":"ème"},{"text":" -  ","color":"#6B788F"},{"score":{"name":"@s","objective":"switch.temp.points"}},{"text":" "},{"selector":"@s","color":"#AEBBD0"}]
tellraw @a[scores={switch.lang=0},tag=!detached] ""

# English
tellraw @a[scores={switch.lang=1},tag=!detached] ["\n",{"nbt":"Paralya","storage":"switch:main","interpret":true},{"text":" Ranking by points:"}]
execute as @a[scores={switch.temp.rank=1}] run tellraw @a[scores={switch.lang=1},tag=!detached] [{"text":"\n1st ","color":"#FFE700"},{"text":" - ","color":"#6B788F"},{"score":{"name":"@s","objective":"switch.temp.points"}},{"text":" "},{"selector":"@s","color":"#AEBBD0"}]
execute as @a[scores={switch.temp.rank=2}] run tellraw @a[scores={switch.lang=1},tag=!detached] [{"text":"\n2nd","color":"#C0C0C0"},{"text":" - ","color":"#6B788F"},{"score":{"name":"@s","objective":"switch.temp.points"}},{"text":" "},{"selector":"@s","color":"#AEBBD0"}]
execute as @a[scores={switch.temp.rank=3}] run tellraw @a[scores={switch.lang=1},tag=!detached] [{"text":"\n3rd","color":"#CD7F32"},{"text":" - ","color":"#6B788F"},{"score":{"name":"@s","objective":"switch.temp.points"}},{"text":" "},{"selector":"@s","color":"#AEBBD0"}]
execute as @a[scores={switch.temp.rank=4..}] run tellraw @s[scores={switch.lang=1}] [{"text":"\n","color":"#AEBBD0"},{"score":{"name":"@s","objective":"switch.temp.rank"}},{"text":"th"},{"text":" - ","color":"#6B788F"},{"score":{"name":"@s","objective":"switch.temp.points"}},{"text":" "},{"selector":"@s","color":"#AEBBD0"}]
tellraw @a[scores={switch.lang=1},tag=!detached] ""

