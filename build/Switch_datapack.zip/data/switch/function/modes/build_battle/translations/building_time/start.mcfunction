
#> switch:modes/build_battle/translations/building_time/start
#
# @executed	in switch:build_battle
#
# @within	switch:modes/build_battle/building_time/start
#

# French
tellraw @a[scores={switch.lang=0},tag=!detached] ["\n",{"nbt":"Paralya","storage":"switch:main","interpret":true},{"text":" Le thème choisi est "},{"nbt":"current_theme.fr","storage":"switch:main","interpret":true,"color":"#FFE60A"},{"text":" !"}]
title @a[scores={switch.lang=0},tag=!detached] times 20 60 20
title @a[scores={switch.lang=0},tag=!detached] title {"text":"Thème choisi","color":"#00E5FF"}
title @a[scores={switch.lang=0},tag=!detached] subtitle {"nbt":"current_theme.fr","storage":"switch:main","interpret":true,"color":"#FFE60A"}

# English
tellraw @a[scores={switch.lang=1},tag=!detached] ["\n",{"nbt":"Paralya","storage":"switch:main","interpret":true},{"text":" The chosen theme is "},{"nbt":"current_theme.en","storage":"switch:main","interpret":true,"color":"#FFE60A"},{"text":"!"}]
title @a[scores={switch.lang=1},tag=!detached] times 20 60 20
title @a[scores={switch.lang=1},tag=!detached] title {"text":"Theme chosen","color":"#00E5FF"}
title @a[scores={switch.lang=1},tag=!detached] subtitle {"nbt":"current_theme.en","storage":"switch:main","interpret":true,"color":"#FFE60A"}

