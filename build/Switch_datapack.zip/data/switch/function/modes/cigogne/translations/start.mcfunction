
#> switch:modes/cigogne/translations/start
#
# @executed	as @n[tag=switch.coupdetat] & in switch:game
#
# @within	switch:modes/cigogne/start
#

# French
tellraw @a[scores={switch.lang=0},tag=!detached] ["\n",{"nbt":"Paralya","storage":"switch:main","interpret":true},{"text":" Lancement de Cigogne dans 10 secondes, vous êtes invisibles et votre objectif est de tuer tous les autres joueurs ! Des particules d'eau apparaissent sous vos pieds si vous ne sneakez pas, et vous obtenez l'effet glowing si vous sneakez pendant 5 secondes de suite !"}]
tellraw @a[scores={switch.lang=0},tag=!detached] ["\n",{"nbt":"ParalyaPvPOldFR","storage":"switch:main","interpret":true}]

# English
tellraw @a[scores={switch.lang=1},tag=!detached] ["\n",{"nbt":"Paralya","storage":"switch:main","interpret":true},{"text":" Launch of Cigogne in 10 seconds, you're invisible and your aim is to kill all the other players! Water particles appear under your feet if you don't sneak, and you get the glowing effect if you sneak for 5 seconds in a row!"}]
tellraw @a[scores={switch.lang=1},tag=!detached] ["\n",{"nbt":"ParalyaPvPOldEN","storage":"switch:main","interpret":true}]

