
#> switch:modes/capture_the_flag/classes/tank
#
# @executed	as the player & at current position
#
# @within	switch:modes/capture_the_flag/classes/main
#

function switch:player/layout/deactivate
function switch:modes/capture_the_flag/classes/_common
item replace entity @s armor.chest with diamond_chestplate
item replace entity @s armor.legs with chainmail_leggings
item replace entity @s armor.feet with iron_boots
item replace entity @s hotbar.0 with stone_sword
item replace entity @s hotbar.1 with stone_axe[attribute_modifiers=[{type:"minecraft:attack_damage",slot:"mainhand",id:"switch.attack_damage",amount:4,operation:"add_value"}]]
item replace entity @s hotbar.2 with golden_apple 2
item replace entity @s hotbar.6 with potion[item_name={"text":"Suicide Potion","color":"#A53DE0"},potion_contents={custom_color:4391004,custom_effects:[{id:"instant_damage",amplifier:1b,duration:20},{id:"wither",amplifier:10b,duration:-1},{id:"poison",amplifier:10b,duration:-1}]}]
item replace entity @s[team=switch.temp.red] hotbar.7 with red_wool 22
item replace entity @s[team=switch.temp.blue] hotbar.7 with blue_wool 22
item replace entity @s hotbar.8 with bread 21
attribute @s movement_speed base set 0.09
attribute @s attack_speed base set 2048
attribute @s max_health base set 24
attribute @s jump_strength base reset

# Layout learned for this kit
scoreboard players set @s switch.layout.kit 8
execute if score @s switch.layout.8cfdf8c7 matches 0.. run function switch:modes/capture_the_flag/classes/tank/layout/apply
tag @s add switch.layout.active

