
#> switch:modes/capture_the_flag/classes/warrior
#
# @executed	as the player & at current position
#
# @within	switch:modes/capture_the_flag/classes/main
#

function switch:modes/capture_the_flag/classes/_common
function switch:modes/capture_the_flag/classes/_soldier_base
item replace entity @s hotbar.3 with potion[potion_contents="minecraft:strong_healing"]
item replace entity @s hotbar.6 with potion[item_name={"text":"Suicide Potion","color":"dark_purple"},potion_contents={custom_color:4391004,custom_effects:[{id:"instant_damage",amplifier:1b,duration:20},{id:"wither",amplifier:10b,duration:-1},{id:"poison",amplifier:10b,duration:-1}]}]
item replace entity @s[team=switch.temp.red] hotbar.7 with red_wool 12
item replace entity @s[team=switch.temp.blue] hotbar.7 with blue_wool 12
item replace entity @s hotbar.8 with bread 21

function switch:modes/capture_the_flag/classes/_soldier_attrs

