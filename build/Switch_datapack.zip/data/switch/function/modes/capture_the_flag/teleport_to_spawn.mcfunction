
#> switch:modes/capture_the_flag/teleport_to_spawn
#
# @executed	as @a[sort=random] & at @s
#
# @within	switch:modes/capture_the_flag/joined
#			switch:modes/capture_the_flag/score_point [ as @p[tag=switch.has_blue_flag] ]
#			switch:modes/capture_the_flag/score_point [ as @p[tag=switch.has_red_flag] ]
#			switch:modes/capture_the_flag/teleport_to_death
#			switch:modes/capture_the_flag/roles/main
#

## Maps spawn
# Map Plains Castles
execute if data storage switch:main {map:"operation_pigclaw"} run tp @s[team=switch.temp.blue] 6298 -19 6251 -135 0
execute if data storage switch:main {map:"operation_pigclaw"} run tp @s[team=switch.temp.red] 6099 -35 6413 45 0
execute if data storage switch:main {map:"ctf_plains_castles"} store result score #random switch.data run random value 0..1
execute if data storage switch:main {map:"ctf_plains_castles"} if score #random switch.data matches 0 run tp @s[team=switch.temp.red] -11675 129 -3862 90 0
execute if data storage switch:main {map:"ctf_plains_castles"} if score #random switch.data matches 1 run tp @s[team=switch.temp.red] -11678 129 -3910 90 0
execute if data storage switch:main {map:"ctf_plains_castles"} if score #random switch.data matches 0 run tp @s[team=switch.temp.blue] -11997 129 -3862 -90 0
execute if data storage switch:main {map:"ctf_plains_castles"} if score #random switch.data matches 1 run tp @s[team=switch.temp.blue] -11997 129 -3910 -90 0
execute if data storage switch:main {map:"ctf_mountains_castles"} run tp @s[team=switch.temp.blue] -11714 201 -5865 180 0
execute if data storage switch:main {map:"ctf_mountains_castles"} run tp @s[team=switch.temp.red] -11922 201 -5865 180 0
execute if data storage switch:main {map:"ctf_flowers"} run tp @s[team=switch.temp.blue] -11813 150 -7969 90 0
execute if data storage switch:main {map:"ctf_flowers"} run tp @s[team=switch.temp.red] -11984 144 -7928 -90 0
execute if data storage switch:main {map:"ctf_nether"} run tp @s[team=switch.temp.blue] -11900 149 -9991 0 0
execute if data storage switch:main {map:"ctf_nether"} run tp @s[team=switch.temp.red] -11898 149 -9659 180 0
execute if data storage switch:main {map:"ctf_forest_castles"} run tp @s[team=switch.temp.blue] -11950 130 -11969 0 0
execute if data storage switch:main {map:"ctf_forest_castles"} run tp @s[team=switch.temp.red] -11950 130 -11817 180 0

## Items to choose a class
tag @s remove switch.to_tp
function switch:player/layout/deactivate
clear @s
attribute @s jump_strength base set 0
effect give @s resistance infinite 250 true
effect give @s slowness infinite 250 true
effect give @s blindness infinite 250 true
effect give @s night_vision infinite 250 true
effect give @s darkness infinite 250 true
gamemode survival @s
scoreboard players set @s switch.temp.chosen_class 0
item replace entity @s hotbar.0 with diamond_chestplate[item_name={"text":"Tank","color":"#FF3347"},custom_data={switch:{class_item:1b,ctf_class:true}},consumable={consume_seconds:1024}]
item replace entity @s hotbar.2 with iron_sword[item_name={"text":"Warrior","color":"#FF3347"},custom_data={switch:{class_item:2b,ctf_class:true}},consumable={consume_seconds:1024}]
item replace entity @s hotbar.4 with arrow[item_name={"text":"Archer","color":"#FF3347"},custom_data={switch:{class_item:3b,ctf_class:true}},consumable={consume_seconds:1024}]
item replace entity @s hotbar.6 with tnt[item_name={"text":"Demolisher","color":"#FF3347"},custom_data={switch:{class_item:4b,ctf_class:true}},consumable={consume_seconds:1024}]
item replace entity @s hotbar.8 with blaze_powder[item_name={"text":"Chemister","color":"#FF3347"},custom_data={switch:{class_item:5b,ctf_class:true}},consumable={consume_seconds:1024}]

