
#> switch:modes/_common/recap/stop
#
# @within	switch:modes/capture_the_flag/stop
#			switch:modes/cigogne/stop
#			switch:modes/glassrunner/stop
#			switch:modes/pillars_of_fortune/stop
#			switch:modes/protect_the_king/stop
#			switch:modes/rush_the_point/stop
#			switch:modes/spectres_game/stop
#

scoreboard objectives remove switch.temp.points
scoreboard objectives remove switch.temp.kills
scoreboard objectives remove switch.temp.deaths
scoreboard objectives remove switch.temp.damage
scoreboard objectives remove switch.temp.recap_rank

