
#> switch:modes/_common/death_spectator
#
# @executed	at @s
#
# @within	switch:modes/bombardement/death
#			switch:modes/spleef/death
#			switch:modes/tnt_run/death
#

execute if entity @s[gamemode=!spectator] run scoreboard players add @s switch.stats.deaths 1

gamemode spectator @s
execute unless score #process_end switch.data matches 1 at @n[type=marker,tag=switch.selected_map] run tp @s ~ ~ ~ ~ ~
effect clear @s
clear @s

