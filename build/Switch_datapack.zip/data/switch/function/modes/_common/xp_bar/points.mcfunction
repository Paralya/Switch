
#> switch:modes/_common/xp_bar/points
#
# @within	switch:modes/_common/xp_bar/time
#			switch:modes/block_party/xp_bar
#			switch:modes/build_battle/xp_bar_preparation
#			switch:modes/build_battle/xp_bar_rating
#			switch:modes/moutron/xp_bar
#

# Divide points
scoreboard players operation #points switch.data /= #divide switch.data
scoreboard players set #divide switch.data 1
execute if score #points switch.data matches ..0 run scoreboard players set #points switch.data 0
execute if score #points switch.data matches 1000.. run scoreboard players set #points switch.data 1000

# XP from 0 to 1000 points
xp set @a[tag=!detached] 130 levels
data modify storage switch:main temp set value {selector:"@a[tag=!detached]", xp:0, type:""}
execute store result storage switch:main temp.xp int 1 run scoreboard players get #points switch.data
function switch:modes/_common/xp_bar/macro with storage switch:main temp
xp set @a[tag=!detached] 0 levels

